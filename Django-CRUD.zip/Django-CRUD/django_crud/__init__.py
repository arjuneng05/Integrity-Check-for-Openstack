default_app_config = 'bsm_sample.apps.SamplesConfig'
